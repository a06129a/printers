import flet as ft
from conexion_bd import get_connection
import re
from functools import partial

class OrdenPedidoView:
    def __init__(self, page: ft.Page, documento_cliente):
        self.page = page
        self.documento_cliente = documento_cliente
        self.mensaje_estado = ft.Text(value="", color="white", size=16)

        def solo_numeros_un_punto(e):
            texto = e.control.value
            filtrado = re.sub(r"[^0-9.]", "", texto)
            if filtrado.count(".") > 1:
                primer_punto = filtrado.find(".")
                filtrado = filtrado[:primer_punto + 1] + filtrado[primer_punto + 1:].replace(".", "")
            e.control.value = filtrado
            self.page.update()

        

        self.cantidad_unidades = ft.TextField(
            bgcolor="#ffffff", 
            color="#000000",
            on_change=self.solo_numeros, 
            width=120
        )
        self.cliente_field = ft.TextField(
            label="Cliente", 
            bgcolor="#ffffff",
            color="#000000",
            label_style=ft.TextStyle(color="#666666"),
            on_change=self.solo_letras_espacios_comas
        )
        self.publicidad_field = ft.TextField(
            label="Publicidad", 
            bgcolor="#ffffff",
            color="#000000",
            label_style=ft.TextStyle(color="#666666") 
        )
        self.trabajo_field = ft.TextField(
            label="Trabajo", 
            bgcolor="#ffffff",
            color="#000000",
            label_style=ft.TextStyle(color="#666666")
        )
        self.cantidad_colores = ft.TextField(
            bgcolor="#ffffff", 
            color="#000000",
            on_change=self.solo_numeros, 
            width=120
        )
        self.detalles = [
            ft.TextField(
                label=f"{i+1}-", 
                bgcolor="#ffffff", 
                color="#000000",
                label_style=ft.TextStyle(color="#666666"),
                width=450
            ) for i in range(6)
        ]
        self.material_dropdown = ft.Dropdown(
            label="Selecciona una opción",
            width=200,
            label_style=ft.TextStyle(color="white"),
            text_style=ft.TextStyle(color="#000000"),
            options=[ft.dropdown.Option(f"Opción {i+1}") for i in range(3)]
        )
        self.cant_material = ft.TextField(
            bgcolor="#ffffff", 
            color="#000000",
            on_change=self.solo_numeros, 
            width=120
        )
        self.ancho_pliego = ft.TextField(
            label="Ancho-cm", 
            bgcolor="#ffffff", 
            color="#000000",
            label_style=ft.TextStyle(color="#666666"),
            on_change=self.validar_numerico,
            width=120
        )
        self.alto_pliego = ft.TextField(
            label="Alto-cm", 
            bgcolor="#ffffff", 
            color="#000000",
            label_style=ft.TextStyle(color="#666666"),
            on_change=self.validar_numerico,
            width=120
        )
        self.espesor_field = ft.TextField(
            bgcolor="#ffffff", 
            color="#000000",
            on_change=self.validar_numerico, 
            width=120
        )
        self.troquelado_switch = ft.Switch(value=False)
        self.doblado_switch = ft.Switch(value=False)
        self.corte_switch = ft.Switch(value=False)
        self.cinta_bifaz_dropdown = ft.Dropdown(
            label="Selecciona una opción", 
            width=200, 
            label_style=ft.TextStyle(color="white"),
            text_style=ft.TextStyle(color="#000000"),
            options=[ft.dropdown.Option(f"Opción {i+1}") for i in range(3)]
        )
        self.observaciones_field = ft.TextField(
            bgcolor="#ffffff", 
            color="#000000",
            multiline=True, 
            max_lines=4, 
            hint_text="Escribe aquí todos los detalles...",
            hint_style=ft.TextStyle(color="#888888")
        )
        self.dia_recepcion = ft.Dropdown(label="Día", width=100)
        self.mes_recepcion = ft.Dropdown(label="Mes", width=130, on_change=self.actualizar_dias_recepcion)
        self.anio_recepcion = ft.Dropdown(label="Año", width=120)

        self.dia_entrega = ft.Dropdown(label="Día", width=100)
        self.mes_entrega = ft.Dropdown(label="Mes", width=130, on_change=self.actualizar_dias_entrega)
        self.anio_entrega = ft.Dropdown(label="Año", width=120)

        self.dia_recepcion.options = self.dia_entrega.options = [ft.dropdown.Option(str(d)) for d in range(1, 32)]
        self.mes_recepcion.options = self.mes_entrega.options = [ft.dropdown.Option(str(m)) for m in range(1, 13)]
        self.anio_recepcion.options = self.anio_entrega.options = [ft.dropdown.Option(str(a)) for a in range(2025, 2031)]

        self.cargar_datos()

    def validar_numerico(self, e):
            valor = e.control.value.strip()

            # Solo permitimos dígitos, puntos y comas
            valor = re.sub(r"[^0-9.,]", "", valor)

            # Reemplazamos coma por punto
            valor = valor.replace(",", ".")

            # Bloqueamos si empieza con punto
            if valor.startswith("."):
                valor = ""

            # Permitimos solo un punto decimal (el primero)
            partes = valor.split(".")
            if len(partes) > 2:
                valor = partes[0] + "." + "".join(partes[1:])

            # Si hay punto decimal, validamos que haya al menos un número antes
            if "." in valor:
                if not re.match(r"^\d+.\d*$", valor):
                    valor = re.sub(r".", "", valor)
                else:
                    # Limitar a máximo 4 decimales
                    entero, decimales = valor.split(".")
                    decimales = decimales[:4]
                    valor = f"{entero}.{decimales}"

            if e.control.value != valor:
                e.control.value = valor
                e.control.update()

    def solo_letras_espacios_comas(self, e):
        texto = e.control.value
        texto_filtrado = re.sub(r"[^a-zA-ZáéíóúÁÉÍÓÚñÑ ,]", "", texto)
        texto_formateado = " ".join(p.capitalize() for p in texto_filtrado.split(" ")) if e.control == self.cliente_field else texto_filtrado.strip().capitalize()
        e.control.value = texto_formateado
        e.control.update()

    def solo_numeros(self, e):
        e.control.value = ''.join(filter(str.isdigit, e.control.value))
        self.page.update()

    def solo_numeros_y_barra(self, e):
        campo = e.control
        campo.value = "".join(c for c in campo.value if c.isdigit() or c == "/")
        self.page.update()

    def actualizar_dias_recepcion(self, e):
        self._actualizar_dias(self.mes_recepcion, self.dia_recepcion)

    def actualizar_dias_entrega(self, e):
        self._actualizar_dias(self.mes_entrega, self.dia_entrega)

    def _actualizar_dias(self, mes_dropdown, dia_dropdown):
        try:
            mes = int(mes_dropdown.value or 1)
        except:
            mes = 1
        dias_31 = [1, 3, 5, 7, 8, 10, 12]
        dias_30 = [4, 6, 9, 11]
        if mes in dias_31:
            max_dia = 31
        elif mes in dias_30:
            max_dia = 30
        else:
            max_dia = 29
        dia_dropdown.options = [ft.dropdown.Option(str(d)) for d in range(1, max_dia + 1)]
        if int(dia_dropdown.value or 0) > max_dia:
            dia_dropdown.value = None
        self.page.update()

    def cargar_datos(self):
        pass  


    def cargar_datos(self):
        try:
            conn = get_connection()
            cursor = conn.cursor()
            cursor.execute("""
                SELECT cantidad_unidades, cliente, publicidad, trabajo, cantidad_colores, detalles,
                    material, cant_material, ancho_pliego, alto_pliego, espesor,
                    troquelado, doblado, corte, cinta_bifaz, observaciones, 
                    fecha_recepcion, fecha_entrega
                FROM OrdenPedido WHERE documento_cliente = ?
            """, (self.documento_cliente,))
            resultado = cursor.fetchone()
            if resultado:
                (
                    self.cantidad_unidades.value,
                    self.cliente_field.value,
                    self.publicidad_field.value,
                    self.trabajo_field.value,
                    self.cantidad_colores.value,
                    detalles_str,
                    self.material_dropdown.value,
                    self.cant_material.value,
                    self.ancho_pliego.value,
                    self.alto_pliego.value,
                    self.espesor_field.value,
                    self.troquelado_switch.value,
                    self.doblado_switch.value,
                    self.corte_switch.value,
                    self.cinta_bifaz_dropdown.value,
                    self.observaciones_field.value,
                    fecha_recepcion,
                    fecha_entrega
                ) = resultado

                if fecha_recepcion and fecha_recepcion.count("/") == 2:
                    d, m, a = fecha_recepcion.split("/")
                    self.dia_recepcion.value = d
                    self.mes_recepcion.value = m
                    self.anio_recepcion.value = f"20{a}"

                if fecha_entrega and fecha_entrega.count("/") == 2:
                    d, m, a = fecha_entrega.split("/")
                    self.dia_entrega.value = d
                    self.mes_entrega.value = m
                    self.anio_entrega.value = f"20{a}"

                detalles_list = detalles_str.split("|||") if detalles_str else [""] * 6
                for i, detalle in enumerate(detalles_list[:6]):
                    if i < len(self.detalles):
                        self.detalles[i].value = detalle

                self.page.update()
        except Exception as ex:
            print(f"Error al cargar datos: {ex}")

    def guardar_pedido(self, e):
        try:
            conn = get_connection()
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS OrdenPedido (
                    documento_cliente TEXT PRIMARY KEY,
                    cantidad_unidades INTEGER,
                    cliente TEXT,
                    publicidad TEXT,
                    trabajo TEXT,
                    cantidad_colores INTEGER,
                    detalles TEXT,
                    material TEXT,
                    cant_material INTEGER,
                    ancho_pliego REAL,
                    alto_pliego REAL,
                    espesor REAL,
                    troquelado BOOLEAN,
                    doblado BOOLEAN,
                    corte BOOLEAN,
                    cinta_bifaz TEXT,
                    observaciones TEXT,
                    fecha_recepcion TEXT,
                    fecha_entrega TEXT,
                    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            detalles_str = "|||".join([detalle.value or "" for detalle in self.detalles])
            cursor.execute("""
                INSERT OR REPLACE INTO OrdenPedido (
                    documento_cliente, cantidad_unidades, cliente, publicidad, trabajo,
                    cantidad_colores, detalles, material, cant_material,
                    ancho_pliego, alto_pliego, espesor, troquelado, doblado, corte,
                    cinta_bifaz, observaciones, fecha_recepcion, fecha_entrega
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                self.documento_cliente,
                int(self.cantidad_unidades.value or 0),
                self.cliente_field.value or "",
                self.publicidad_field.value or "",
                self.trabajo_field.value or "",
                int(self.cantidad_colores.value or 0),
                detalles_str,
                self.material_dropdown.value or "",
                int(self.cant_material.value or 0),
                float(self.ancho_pliego.value or 0),
                float(self.alto_pliego.value or 0),
                float(self.espesor_field.value or 0),
                self.troquelado_switch.value,
                self.doblado_switch.value,
                self.corte_switch.value,
                self.cinta_bifaz_dropdown.value or "",
                self.observaciones_field.value or "",
                f"{(self.dia_recepcion.value or '').zfill(2)}/"
                f"{(self.mes_recepcion.value or '').zfill(2)}/"
                f"{(self.anio_recepcion.value or '')[-2:]}",

                f"{(self.dia_entrega.value or '').zfill(2)}/"
                f"{(self.mes_entrega.value or '').zfill(2)}/"
                f"{(self.anio_entrega.value or '')[-2:]}"

            ))
            conn.commit()
            conn.close()
            self.mensaje_estado.value = "Pedido guardado exitosamente"
            self.mensaje_estado.color = "green"
            self.page.update()
            self.page.go("/clientes")
        except Exception as ex:
            print(f"Error al guardar pedido: {ex}")
            self.mensaje_estado.value = f"Error al guardar: {ex}"
            self.mensaje_estado.color = "red"
            self.page.update()

    def texto_bloque(self, texto, padding_left=60, padding_top=15, margin=None):
        return ft.Container(
            ft.Text(texto, size=17, color="#ffffff"),
            margin=margin if margin else ft.margin.only(left=20),
            padding=ft.padding.only(left=padding_left, top=padding_top),
            width=240,
            height=50,
            bgcolor="#1d4fe0",
            border_radius=ft.BorderRadius(top_left=30, top_right=0, bottom_left=30, bottom_right=0)
        )

    def view(self):
        self.page.title = "Orden de pedido"
        self.page.bgcolor = "#1976d2"
        self.page.scroll = "auto"
        self.page.padding = 0

        contenedor = ft.Container(
            content=ft.Text("Orden pedido", color="#ffffff", font_family="Times New Roman", size=30),
            padding=15,
            width=250,
            height=70,
            bgcolor="#122ecc",
            border_radius=ft.BorderRadius(0, 0, 0, 60)
        )

        Datos_columnas = ft.Column([
            contenedor,
            ft.Container(content=self.cliente_field, width=340, margin=ft.margin.only(left=30)),
            ft.Container(content=self.publicidad_field, width=340, margin=ft.margin.only(left=30)),
            ft.Container(content=self.trabajo_field, width=340, margin=ft.margin.only(left=30))
        ], spacing=30)

        columna = ft.Column([
            ft.Row([self.texto_bloque("Cantidad Unidad/es"), self.cantidad_unidades])
        ], spacing=20)

        datos_fila = ft.Row([Datos_columnas, columna], spacing=100)

        entry_fila2 = ft.Row([
            self.texto_bloque("Cantidad de colores", padding_left=14),
            ft.Container(self.cantidad_colores)
        ])

        lista2 = ft.Column([
            self.texto_bloque("Detalles:", padding_left=60),
            *[ft.Container(detalle, margin=ft.margin.only(left=120)) for detalle in self.detalles]
        ], spacing=10)

        lista4 = ft.Row([
            self.texto_bloque("Material", padding_left=60),
            self.material_dropdown,
            self.texto_bloque("Cant. Material", padding_left=40, margin=ft.margin.only(left=400)),
            ft.Container(self.cant_material)
        ])

        lista5 = ft.Row([
            self.texto_bloque("Med. pliego", padding_left=40),
            ft.Container(self.ancho_pliego),
            ft.Container(self.alto_pliego),
            self.texto_bloque("Espesor", padding_left=70, margin=ft.margin.only(left=350)),
            ft.Container(self.espesor_field)
        ])

        lista6 = ft.Row([
            *[
                ft.Container(ft.Row([
                    ft.Text(texto, size=18, color="#ffffff"),
                    switch
                ]), padding=10) for texto, switch in [
                    ("Troquelado", self.troquelado_switch), 
                    ("Doblado", self.doblado_switch), 
                    ("Corte", self.corte_switch)
                ]
            ],
            ft.Row([
                self.texto_bloque("Cinta bifaz", padding_left=60),
                self.cinta_bifaz_dropdown
            ])
        ], spacing=80)

        datos_fila2 = ft.Row([
            self.texto_bloque("Observaciones", padding_left=40),
            ft.Container(self.observaciones_field, width=600)
        ], alignment=ft.MainAxisAlignment.CENTER)

        lista7 = ft.Row(
            [
                ft.Row([
                    self.texto_bloque("Fecha recepción", padding_left=40),
                    self.dia_recepcion, self.mes_recepcion, self.anio_recepcion
                ]),
                ft.Row([
                    self.texto_bloque("Fecha entrega", padding_left=50),
                    self.dia_entrega, self.mes_entrega, self.anio_entrega
                ])
            ],
            spacing=250,
            scroll=ft.ScrollMode.ALWAYS  # ← scroll se aplica directamente a la Row
        )


        botones_finales = ft.Row([
            ft.ElevatedButton("Volver", on_click=lambda e: self.page.go("/costos"), bgcolor="white"),
            ft.ElevatedButton("Guardar Pedido", on_click=self.guardar_pedido, bgcolor="green", color="white"),
            ft.ElevatedButton("Cancelar", on_click=lambda e: self.page.go("/clientes"), bgcolor="red", color="white"),
        ], alignment=ft.MainAxisAlignment.END)

        separador = ft.Divider(color=ft.Colors.BLUE_GREY_200)

        return ft.View(
            route="/orden_pedido",
            scroll=ft.ScrollMode.ALWAYS,
            bgcolor="#1976d2",
            controls=[
                ft.Column([
                    datos_fila, separador, entry_fila2, lista2,
                    separador, lista4, lista5, lista6, datos_fila2,
                    separador, lista7, self.mensaje_estado, botones_finales
                ])
            ]
        )